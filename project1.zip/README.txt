Extreme Landing

Created by Trung Nguyen

1. How to play the game?
- Use Right and Left arrows to move forward and backward
- Use Up arrow to rotate clockwise and right arrow to rotate counterclockwise
- Maneuver the player through terrain to the finish line 
- if the head of the player touches the ground the game or level restarts

2. Assets
- https://assetstore.unity.com/packages/2d/environments/2d-spriteshape-ferr2d-textures-pack-ice-97363 (Unity Asset Store): Ice_01_Top 2 2D Sprite
- https://assetstore.unity.com/packages/2d/characters/pixel-motorcycle-pack-191962 (Unity Asset Store): biker/biker.png, cbr1000rr/bike.png